#!/usr/bin/env bash
set -eu
prep=/root/autodl-tmp/0z5a/flashrlt-h20-20261006/learner-prep-v1
cd "$prep"
test "$(cat /proc/sys/kernel/random/boot_id)" = 797c630e-4da1-48bd-bdf3-daabf26649d2
test "$(nvidia-smi --query-gpu=uuid --format=csv,noheader)" = GPU-edf64e5f-21ef-a1f2-6601-e8620b5664ff
exec 9</root/autodl-tmp/0z5a-coordination/h20/gpu0.lock
exec 8</root/autodl-tmp/0z5a-coordination/h20/io.lock
test "$(stat -Lc %i /proc/$$/fd/9)" = 12920245107
test "$(stat -Lc %i /proc/$$/fd/8)" = 12920245108
flock -n 9
flock -n 8
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(cat results/exit-code.txt)" = 0
test "$(cat results/setuptools-repair/exit-code.txt)" = 0
test "$(cat results/setuptools-repair/pip-check.log)" = 'No broken requirements found.'
cmp results/base-packages-before.json results/setuptools-repair/base-packages-after.json
gate="$prep/mcore-gate-v2"
mkdir "$gate"
cp mcore-controller-v2.sh "$gate/controller.sh"
cat /proc/$$/stat > "$gate/controller-proc-stat.txt"
date -u +%FT%TZ > "$gate/started-utc.txt"
trap 'gate_exit=$?; printf "%s\n" "$gate_exit" > "$gate/exit-code.txt"; date -u +%FT%TZ > "$gate/ended-utc.txt"' EXIT
sha256sum -c packet.sha256 > "$gate/packet-verified.txt"
export PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=1
export CUDA_DEVICE_MAX_CONNECTIONS=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONPATH="$prep/sources/vime:$prep/sources/rlt:$prep/sources/megatron:$prep/sources/vime/tests/plugins"
env_python=/root/autodl-tmp/0z5a/envs/flashrlt-cu130/bin/python
"$env_python" -c 'import torch; assert torch.cuda.is_available(); print(torch.__version__, torch.cuda.get_device_name())' > "$gate/device.txt" 2>&1
"$env_python" -m pip list --format=json > "$gate/environment.json"
cd sources/vime
"$env_python" -m pytest tests/integration/test_native_prefix_train_step.py \
    -q -p no:cacheprovider --tb=short -o junit_family=legacy --basetemp="$gate/pytest-tmp" \
    --junitxml="$gate/results.xml" > "$gate/pytest.log" 2>&1 &
test_pid=$!
cat /proc/$test_pid/stat > "$gate/test-proc-stat.txt"
wait "$test_pid"
