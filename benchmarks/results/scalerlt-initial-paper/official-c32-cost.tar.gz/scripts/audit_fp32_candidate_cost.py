"""Offbox audit of every retained fixed-work trial; no Torch or CUDA imports."""

import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path

SOURCE = "e8aa1ee57734bc5c1118c143ebdb68d0b53210a1"
PIN = "574fa66cb8bf5abdc979642d01cf2b79b16bfab1"


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def signature(trial):
    return [
        (r["ordinal"], r["request_id"], r["token_ids"], r["exit_depths"], r["finish_reason"])
        for r in trial["requests"]
    ]


def finite(value):
    assert math.isfinite(value)
    return value


def check_distribution(record, values):
    assert values and all(math.isfinite(v) and v >= 0 for v in values)
    ordered = sorted(values)
    expected = dict(
        n=len(values),
        mean=statistics.mean(values),
        median=statistics.median(values),
        p95=ordered[math.ceil(0.95 * len(values)) - 1],
        p99=ordered[math.ceil(0.99 * len(values)) - 1],
        min=ordered[0],
        max=ordered[-1],
    )
    assert record.keys() == expected.keys()
    for key, value in expected.items():
        assert math.isclose(record[key], value, rel_tol=1e-12, abs_tol=1e-12), key


def histogram(hist, maximum, required=False):
    assert hist and all(int(k) >= 0 and int(v) > 0 for k, v in hist.items())
    actual = max(map(int, hist))
    assert actual <= maximum
    if required:
        assert actual == maximum
    return actual


def audit(folder, protocol_path, candidate_path):
    protocol, candidate, status = (
        read(protocol_path),
        read(candidate_path),
        read(folder / "status.json"),
    )
    assert protocol["state"] == "FROZEN_FP32_CANDIDATE_COST"
    assert candidate["state"] == "PROVISIONAL_FOR_COST"
    assert digest(candidate_path) == protocol["candidate_sha256"]
    assert protocol["source_sha"] == candidate["source_sha"] == SOURCE
    assert protocol["dtype"] == candidate["dtype"] == "float32"
    assert protocol["attention_backend"] == candidate["attention_backend"] == "triton"
    assert protocol["request_scope"] == "INITIAL_C_TOTAL_C_NO_REFILL"
    assert protocol["requests_per_trial"] == "C" and protocol["cuda_graphs"] is False
    assert protocol["warmups"] == protocol["measurements"] == 5
    assert protocol["model_revision"] == PIN
    assert protocol["prefill_depth"] == 4 and protocol["kv_gib"] == 64
    assert protocol["input_length"] == 512 and protocol["output_tokens"] == 128
    assert candidate["decode_depth"] in (2, 3) and 0 < candidate["strength"] <= 1
    case = status["case"]
    assert case in ("B16C32", "B32C64")
    batch, count = (16, 32) if case == "B16C32" else (32, 64)
    expected = [(0, "A"), (0, "B"), (0, "C"), (1, "C"), (1, "B"), (1, "A")]
    assert status["protocol_sha256"] == digest(protocol_path)
    assert status["candidate_sha256"] == digest(candidate_path)
    assert status["source_sha"] == SOURCE
    assert status["status"] in ("COMPLETE", "WAITING_NEXT_WINDOW")
    assert 1 <= len(status["jobs"]) <= 6 and all(j["exit_code"] == 0 for j in status["jobs"])
    assert (status["status"] == "COMPLETE") == (len(status["jobs"]) == 6)
    policies, rows = {}, []
    total_trials = 0
    for ordinal, job in enumerate(status["jobs"]):
        fresh, arm = expected[ordinal]
        label = f"{case}-fresh{fresh}-{arm}"
        assert job["name"] == label
        manifest = read(folder / (label + ".manifest.json"))
        depth = 4 if arm == "A" else candidate["decode_depth"]
        enabled = arm == "C"
        assert manifest["arm"] == arm and manifest["fresh"] == fresh
        assert manifest["source_sha"] == SOURCE
        assert manifest["protocol_sha256"] == digest(protocol_path)
        assert manifest["candidate_sha256"] == digest(candidate_path)
        assert manifest["trial_observer_sha256"] == protocol["trial_observer_sha256"]
        assert (
            manifest["instrumentation"] == "NEUTRAL_CORE_HEAD_SCHEDULE_METADATA_WRAPPERS_ALL_ARMS"
        )
        assert manifest["dtype"] == "float32" and manifest["attention_backend"] == "triton"
        assert manifest["B"] == batch and manifest["C"] == count
        assert manifest["model_parameter_dtype"] == "torch.float32"
        assert manifest["model_parameter_device"].startswith("cuda")
        assert manifest["cache_config"]["layout"] == "last_exited"
        assert manifest["cache_config"]["block_size"] == 16
        assert manifest["cache_config"]["kv_cache_memory_bytes"] == 64 * 1024**3
        assert manifest["requests_per_trial"] == count
        assert manifest["request_scope"] == "INITIAL_C_TOTAL_C_NO_REFILL"
        assert manifest["prefill_depth"] == 4 and manifest["decode_depth"] == depth
        assert manifest["execution"]["loopcd"] is enabled
        assert manifest["execution"]["cuda_graphs"] is False
        sampling = manifest["sampling"]
        assert sampling["min_loops"] == sampling["max_loops"] == depth
        assert sampling["max_tokens"] == 128 and sampling["ignore_eos"] is True
        assert sampling["temperature"] == 0
        if enabled:
            assert sampling["loopcd"]["implementation"] == "two_head"
            assert sampling["loopcd"]["strength"] == candidate["strength"]
        else:
            assert sampling["loopcd"] is None
        trials = sorted((folder / label).glob("trial-*.json"))
        assert len(trials) == 10
        summary = read(folder / label / "summary.json")
        assert len(summary) == 10
        measured = []
        for index, path in enumerate(trials):
            trial = read(path)
            assert trial["index"] == index
            assert trial["phase"] == ("warmup" if index < 5 else "measured")
            assert trial["drained"] and trial["repeat_parity"]
            assert trial["admission_timestamp_scope"] == "SCHEDULE_RETURN_BEFORE_MODEL_EXECUTE"
            assert trial["resident_observation_scope"] == "POST_SCHEDULE_PRE_EXECUTE"
            assert trial["kv_peak_observation_scope"] == "SCHEDULE_CORE_CODA_POSTSTEP_METADATA"
            assert len(trial["requests"]) == count
            ids = set()
            for request_ordinal, request in enumerate(trial["requests"]):
                assert request["ordinal"] == request_ordinal
                assert request["admission_boundary"] == "SCHEDULE_RETURN_BEFORE_MODEL_EXECUTE"
                assert len(request["prompt"]) == 512
                assert len(request["token_ids"]) == len(request["delivery_s"]) == 128
                assert request["exit_depths"] == [4] + [depth] * 127
                assert request["finish_reason"] == "length"
                assert request["request_id"] not in ids
                ids.add(request["request_id"])
                assert 0 <= int(request["request_id"].removeprefix("slot-")) < count
                assert (
                    0 <= request["submitted_s"] <= request["admitted_s"] <= request["delivery_s"][0]
                )
                assert all(math.isfinite(v) for v in request["delivery_s"])
                assert request["delivery_s"] == sorted(request["delivery_s"])
                assert request["delivery_s"][-1] == request["finished_s"]
            assert (
                hashlib.sha256(
                    json.dumps([r["prompt"] for r in trial["requests"]]).encode()
                ).hexdigest()
                == manifest["prompt_sha256"]
            )
            requests = trial["requests"]
            check_distribution(
                trial["ttft_s"], [r["delivery_s"][0] - r["submitted_s"] for r in requests]
            )
            check_distribution(
                trial["tpot_s"],
                [(r["delivery_s"][-1] - r["delivery_s"][0]) / 127 for r in requests],
            )
            check_distribution(
                trial["latency_s"], [r["finished_s"] - r["submitted_s"] for r in requests]
            )
            check_distribution(
                trial["admission_wait_s"], [r["admitted_s"] - r["submitted_s"] for r in requests]
            )
            check_distribution(
                trial["itl_s"],
                [b - a for r in requests for a, b in zip(r["delivery_s"], r["delivery_s"][1:])],
            )
            assert max(r["finished_s"] for r in requests) <= trial["elapsed_s"]
            neutral, work = trial["neutral_core_head_work"], trial["loopcd_work"]
            assert (
                neutral["prefill_core_rows"] == neutral["prefill_submitted_rows"] == count * 512 * 4
            )
            assert (
                neutral["decode_core_rows"]
                == neutral["decode_submitted_rows"]
                == count * 127 * depth
            )
            assert neutral["head_rows"] == count * 128 * (2 if enabled else 1)
            assert neutral["head_calls"] > 0
            assert work["guided_rows"] == (count * 128 if enabled else 0)
            assert work["captures"] == (count * (4 + 127) if enabled else 0)
            assert work["head_rows"] == (neutral["head_rows"] if enabled else 0)
            for key in (
                "prefill_core_rows",
                "prefill_submitted_rows",
                "decode_core_rows",
                "decode_submitted_rows",
            ):
                assert work[key] == (neutral[key] if enabled else 0)
            assert (trial["reference_peak_bytes"] > 0) is enabled
            assert trial["kv_pool_bytes"] == manifest["kv_pool_bytes"]
            assert manifest["kv_num_blocks"] == (64 * 1024**3) // manifest["kv_bytes_per_block"]
            assert manifest["kv_pool_bytes"] == (
                manifest["kv_num_blocks"] * manifest["kv_bytes_per_block"]
            )
            assert 0 <= 64 * 1024**3 - trial["kv_pool_bytes"] < manifest["kv_bytes_per_block"]
            assert trial["graph"] == dict(captures=0, replays=0, fallbacks=0)
            assert histogram(trial["outstanding_histogram"], count, True) == count
            assert histogram(trial["resident_histogram"], batch, True) == batch
            assert histogram(trial["resident_poststep_histogram"], batch) <= batch
            assert 0 < trial["kv_peak_blocks"] <= manifest["kv_num_blocks"]
            assert histogram(trial["decode_effective_rows_histogram"], batch, True) == batch
            assert finite(trial["elapsed_s"]) > 0
            assert abs(trial["tps"] * trial["elapsed_s"] - count * 128) < 1e-6
            assert abs(trial["rps"] * trial["elapsed_s"] - count) < 1e-6
            assert summary[index] == {k: v for k, v in trial.items() if k != "requests"}
            current = signature(trial)
            assert arm not in policies or policies[arm] == current, (
                f"same-policy mismatch {label}/{index}"
            )
            policies[arm] = current
            if index >= 5:
                measured.append(trial)
            total_trials += 1
        rows.append(
            dict(
                label=label,
                arm=arm,
                fresh=fresh,
                B=batch,
                C=count,
                dtype="float32",
                attention_backend="triton",
                decode_depth=depth,
                loopcd_enabled=enabled,
                measured_tps_mean=statistics.mean(t["tps"] for t in measured),
                measured_tps_median=statistics.median(t["tps"] for t in measured),
                measured_ttft_ms_mean=1000 * statistics.mean(t["ttft_s"]["mean"] for t in measured),
                measured_tpot_ms_mean=1000 * statistics.mean(t["tpot_s"]["mean"] for t in measured),
                measured_latency_ms_mean=1000
                * statistics.mean(t["latency_s"]["mean"] for t in measured),
                observed_A=batch,
                observed_S=batch,
                observed_C=count,
                whole_job_elapsed_s=job["finished"] - job["started"],
                peak_allocated_bytes=max(t["peak_allocated_bytes"] for t in measured),
                peak_reserved_bytes=max(t["peak_reserved_bytes"] for t in measured),
            )
        )
    return dict(
        status="FULL_CASE_RAW_PASS" if len(rows) == 6 else "PARTIAL_CASE_RAW_PASS_NO_COST_GATE",
        case=case,
        processes=len(rows),
        raw_trials=total_trials,
        total_requests=total_trials * count,
        total_outputs=total_trials * count * 128,
        rows=rows,
        scope=(
            "Native instrumented fixed-work cost; initialC/totalC/no4C-refill; "
            "no quality/HTTP/engine-async claim"
        ),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.folder, args.protocol, args.candidate)
    assert not args.output.exists()
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
