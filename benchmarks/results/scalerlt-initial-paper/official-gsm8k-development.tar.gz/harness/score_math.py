"""Score frozen GSM8K outputs; missing work stays in the declared denominator."""

import argparse
import hashlib
import json
import re
from pathlib import Path

from paired_quality import classify, paired_ci


def normalize(value: str) -> str:
    for pattern in (",", r"\$", r"(?s).*#### ", r"\.$"):
        value = re.sub(pattern, "", value)
    return value.lower()


def extract(text: str, pattern: str) -> str:
    match = re.search(pattern, text)
    return normalize(match[1]) if match else "[invalid]"


def score(plan: dict, records: list[dict]) -> dict:
    expected = {row["problem_id"]: row for row in plan["records"]}
    assert len(expected) == len(plan["records"]), "duplicate frozen IDs"
    assert all(row["task"] == "gsm8k" for row in expected.values())
    arm_ids = [arm["arm_id"] for arm in plan["arms"]]
    assert len(set(arm_ids)) == len(arm_ids)
    by_arm = {arm: {} for arm in arm_ids}
    for row in records:
        assert row["arm_id"] in by_arm and row["problem_id"] in expected
        outputs = by_arm[row["arm_id"]]
        assert row["problem_id"] not in outputs, "duplicate generated ID"
        outputs[row["problem_id"]] = row
    quality = plan["quality"]
    assert quality["family_alpha"] == 0.05
    scored, summaries, correctness = [], [], {}
    for arm_id in arm_ids:
        outputs, successes = by_arm[arm_id], {}
        completed = truncated = 0
        for problem_id, problem in expected.items():
            row = outputs.get(problem_id)
            status = row["runtime_status"] if row else "MISSING_OUTPUT"
            complete = status == "COMPLETE"
            prediction = (
                extract(row["scoring_text"], quality["strict_math_pattern"])
                if complete
                else "[invalid]"
            )
            gold = normalize(problem["gold"].rsplit("####", 1)[-1].strip())
            correct = complete and prediction == gold
            completed += complete
            truncated += complete and row["hit_max_tokens"]
            successes[problem_id] = correct
            scored.append(
                {
                    "arm_id": arm_id,
                    "problem_id": problem_id,
                    "runtime_status": status,
                    "scorer_status": "COMPLETE",
                    "prediction": prediction,
                    "gold": gold,
                    "correct": correct,
                    "hit_max_tokens": row["hit_max_tokens"] if complete else None,
                }
            )
        correctness[arm_id] = successes
        summaries.append(
            {
                "arm_id": arm_id,
                "n": len(expected),
                "completed": completed,
                "missing_or_unrun": len(expected) - completed,
                "correct": sum(successes.values()),
                "accuracy": sum(successes.values()) / len(expected),
                "hit_max_tokens": truncated,
                "status": "COMPLETE" if completed == len(expected) else "INCOMPLETE",
            }
        )
    pairs = [(arm, arm_ids[0]) for arm in arm_ids[1:]]
    if len(arm_ids) == 6:
        pairs += [(arm_ids[3], arm_ids[2]), (arm_ids[5], arm_ids[4])]
    completed_by_arm = {row["arm_id"]: row["status"] == "COMPLETE" for row in summaries}
    comparisons = []
    for candidate, baseline in pairs:
        c, b = correctness[candidate], correctness[baseline]
        wins = sum(c[key] and not b[key] for key in expected)
        losses = sum(b[key] and not c[key] for key in expected)
        interval = paired_ci(wins, losses, len(expected), quality["family_comparisons"])
        complete = completed_by_arm[candidate] and completed_by_arm[baseline]
        status = classify(
            interval["lower"],
            interval["upper"],
            complete=complete,
            scorer_ran=True,
            delta=quality["delta"],
        )
        comparisons.append(
            {
                "candidate": candidate,
                "baseline": baseline,
                **interval,
                "status": status,
                "scope": "exploratory; no confirmation claim"
                if plan["stage"] == "development"
                else "frozen confirmation",
            }
        )
    return {
        "stage": plan["stage"],
        "scorer": "reloop-lm_eval-strict-math-v1",
        "records": scored,
        "arms": summaries,
        "comparisons": comparisons,
        "denominator_policy": "all unique frozen IDs; missing work makes comparison INCOMPLETE",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--records", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    rows = [json.loads(line) for line in args.records.read_text().splitlines() if line]
    plan_sha = hashlib.sha256(args.plan.read_bytes()).hexdigest()
    assert all(row["protocol_sha256"] == plan_sha for row in rows)
    result = score(plan, rows)
    result.update(
        protocol_sha256=plan_sha,
        records_sha256=hashlib.sha256(args.records.read_bytes()).hexdigest(),
        scorer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    )
    with args.out.open("x") as stream:
        json.dump(result, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(
        json.dumps({"arms": result["arms"], "comparisons": result["comparisons"]}),
        flush=True,
    )


if __name__ == "__main__":
    main()
