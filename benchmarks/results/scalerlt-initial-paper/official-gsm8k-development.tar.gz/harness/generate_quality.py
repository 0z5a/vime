"""Re:Loop six-arm natural-stop screening through the public model loader."""

import argparse
import gc
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time
from dataclasses import asdict
from pathlib import Path

ARMS = [
    {
        "arm_id": f"{letter}_P4D{depth}_{'on' if guided else 'off'}",
        "depth": depth,
        "guidance": guided,
        "strength": 0.3 if guided else 0.0,
    }
    for letter, depth, guided in zip("ABCDEF", (4, 4, 3, 3, 2, 2), (False, True) * 3)
]


def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def write(path: Path, value) -> None:
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def setup(plan, source: Path, support: Path) -> None:
    observed = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=source, text=True
    ).strip()
    assert observed == plan["source_sha"], "source changed after protocol freeze"
    subprocess.run(["git", "diff", "--quiet", "HEAD"], cwd=source, check=True)
    sys.path[:0] = [str(source), str(support)]
    import task0_support
    import vllm_rlt

    assert Path(vllm_rlt.__file__).resolve().parents[1] == source.resolve()
    assert file_hash(Path(task0_support.__file__)) == plan["support_sha256"]
    task0_support.verify_public_source()


def tokenize(args) -> None:
    plan = json.loads(args.plan.read_text())
    setup(plan, args.source, args.support)
    import torch
    from vllm_rlt.models import load_tokenizer

    tokenizer = load_tokenizer(plan["model_path"], revision=plan["model_revision"])
    data = json.loads(args.data.read_text())
    assert len({row["problem_id"] for row in data["records"]}) == len(data["records"])
    for record in data["records"]:
        ids = tokenizer.encode(record["prompt"], add_special_tokens=False)
        if "prompt_ids" in record:
            assert ids == record["prompt_ids"], "canonical code prompt IDs changed"
        record["prompt_ids"] = ids
    config = json.loads((Path(plan["model_path"]) / "config.json").read_text())
    bytes_per_token_per_depth = (
        2
        * config["num_hidden_layers"]
        * config["num_key_value_heads"]
        * (config["hidden_size"] // config["num_attention_heads"])
        * 4
    )
    block = plan["cache_config"]["block_size"]
    block_bytes = block * bytes_per_token_per_depth * plan["prefill_depth"]
    capacities = []
    for start in range(0, len(data["records"]), plan["batch_limit"]):
        rows = data["records"][start : start + plan["batch_limit"]]
        spans = [len(row["prompt_ids"]) + plan["max_new_tokens"] - 1 for row in rows]
        assert max(spans) <= config["max_position_embeddings"]
        required = sum((span + block - 1) // block for span in spans)
        available = plan["cache_config"]["kv_cache_memory_bytes"] // block_bytes
        assert required <= available, "common R4 KV pool cannot admit this cohort"
        capacities.append(
            {
                "start": start,
                "configured_C": len(rows),
                "worst_span_tokens": max(spans),
                "required_blocks": required,
                "available_blocks": available,
                "required_bytes": required * block_bytes,
            }
        )
    assert not torch.cuda.is_initialized()
    plan.update(
        records=data["records"],
        raw_data_sha256=file_hash(args.data),
        driver_sha256=file_hash(Path(__file__)),
        tokenizer_versions={
            p: importlib.metadata.version(p) for p in ("transformers", "tokenizers")
        },
        tokenization={
            "add_special_tokens": False,
            "chat_template": False,
            "truncation": False,
        },
        capacity={
            "accounting_depth": plan["prefill_depth"],
            "bytes_per_token_per_depth": bytes_per_token_per_depth,
            "block_bytes": block_bytes,
            "cohorts": capacities,
            "scope": "static upper bound; actual resident A/decode S not inferred",
        },
    )
    write(args.output, plan)
    print(
        json.dumps(
            {
                "status": "FROZEN",
                "records": len(data["records"]),
                "protocol_sha256": file_hash(args.output),
            }
        ),
        flush=True,
    )


def generate(args) -> None:
    plan = json.loads(args.plan.read_text())
    assert file_hash(Path(__file__)) == plan["driver_sha256"]
    setup(plan, args.source, args.support)
    import torch
    from task0_support import drive
    from vllm_rlt import (
        CacheConfig,
        ExecutionConfig,
        LoopCDParams,
        SamplingParams,
        SchedulerConfig,
    )
    from vllm_rlt.engine.llm_engine import LLMEngine
    from vllm_rlt.models import AutoModelForCausalLM, load_tokenizer

    assert plan["dtype"] == "float32" and plan["prefill_depth"] == 4
    assert plan["attention_backend"] == "triton" and not plan["cuda_graphs"]
    assert (
        time.time() + plan["batch_finish_allowance_seconds"] < plan["archive_by_unix"]
    )
    model_path = Path(plan["model_path"])
    for name, expected in plan["model_files"].items():
        assert file_hash(model_path / name) == expected
    torch.set_num_threads(1)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    args.output.mkdir(exist_ok=False)
    started = time.perf_counter()
    model = AutoModelForCausalLM.from_pretrained(
        str(model_path),
        revision=plan["model_revision"],
        device="cuda",
        dtype=torch.float32,
    )
    assert model.config.total_ut_steps == 4
    assert next(model.parameters()).dtype == torch.float32
    tokenizer = load_tokenizer(str(model_path), revision=plan["model_revision"])
    runtime = {
        "protocol_sha256": file_hash(args.plan),
        "source_sha": plan["source_sha"],
        "driver_sha256": file_hash(Path(__file__)),
        "pid": os.getpid(),
        "python": sys.executable,
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "packages": {
            p: importlib.metadata.version(p)
            for p in ("transformers", "tokenizers", "triton", "safetensors")
        },
        "device": torch.cuda.get_device_name(),
        "uuid": str(torch.cuda.get_device_properties(0).uuid),
        "scope": "single-model-load development generation; natural stops; not fixed-work speed or HTTP",
        "model_load_count": 1,
        "dtype": str(next(model.parameters()).dtype),
        "source_root": str(args.source),
    }
    assert runtime["uuid"].removeprefix("GPU-") == plan["gpu_uuid"].removeprefix("GPU-")
    write(args.output / "runtime.json", runtime)
    generated = 0
    records_path = args.output / "records.jsonl"
    arm_summaries = []
    for arm in plan["arms"]:
        engine = LLMEngine(
            model,
            cache_config=CacheConfig(**plan["cache_config"]),
            scheduler_config=SchedulerConfig(**plan["scheduler_config"]),
            execution_config=ExecutionConfig(
                loopcd=arm["guidance"], prefill_depth=4, cuda_graphs=False
            ),
            attention_backend="triton",
        )
        assert engine.cache_manager.key_cache.dtype == torch.float32
        assert engine.cache_manager.value_cache.dtype == torch.float32
        sampling = SamplingParams(
            max_tokens=plan["max_new_tokens"],
            min_loops=arm["depth"],
            max_loops=arm["depth"],
            temperature=0.0,
            ignore_eos=False,
            loopcd=LoopCDParams(
                reference_loop=1, strength=arm["strength"], implementation="two_head"
            )
            if arm["guidance"]
            else None,
        )
        torch.cuda.reset_peak_memory_stats()
        arm_dir = args.output / arm["arm_id"]
        arm_dir.mkdir()
        write(
            arm_dir / "resolved.json",
            {
                "arm": arm,
                "sampling": asdict(sampling),
                "scheduler": asdict(engine.scheduler.config),
                "cache": plan["cache_config"],
                "memory_plan": engine.memory_plan,
            },
        )
        batches = []
        for task in dict.fromkeys(row["task"] for row in plan["records"]):
            cohort = [row for row in plan["records"] if row["task"] == task]
            for start in range(0, len(cohort), plan["batch_limit"]):
                rows = cohort[start : start + plan["batch_limit"]]
                budget_ok = (
                    time.perf_counter() - started < plan["gpu_residence_budget_seconds"]
                    and time.time() + plan["batch_finish_allowance_seconds"]
                    < plan["archive_by_unix"]
                    and generated + len(rows) * sampling.max_tokens
                    <= plan["generated_token_budget"]
                )
                if not budget_ok:
                    with records_path.open("a") as stream:
                        for row in rows:
                            stream.write(
                                json.dumps(
                                    {
                                        "problem_id": row["problem_id"],
                                        "task": task,
                                        "arm_id": arm["arm_id"],
                                        "protocol_sha256": runtime["protocol_sha256"],
                                        "runtime_status": "NOT_RUN_BUDGET",
                                    }
                                )
                                + "\n"
                            )
                    continue
                stops = rows[0]["stops"]
                assert all(row["stops"] == stops for row in rows)
                result = drive(
                    engine,
                    [row["prompt_ids"] for row in rows],
                    sampling,
                    0,
                    tokenizer=tokenizer,
                    stops=stops,
                )
                write(arm_dir / f"{task}-{start:04d}.json", result)
                with records_path.open("a") as stream:
                    for ordinal, row in enumerate(rows):
                        output = result["outputs"][str(ordinal)]
                        ids, depths = output["token_ids"], output["exit_depths"]
                        assert depths == [4] + [arm["depth"]] * (len(ids) - 1)
                        text = tokenizer.decode(ids, skip_special_tokens=True)
                        positions = [text.index(stop) for stop in stops if stop in text]
                        scored_text = text[: min(positions)] if positions else text
                        record = {
                            **arm,
                            "problem_id": row["problem_id"],
                            "task": task,
                            "protocol_sha256": runtime["protocol_sha256"],
                            "source_sha": plan["source_sha"],
                            "prompt_token_ids": row["prompt_ids"],
                            "generated_token_ids": ids,
                            "generated_text": text,
                            "scoring_text": scored_text,
                            "exit_depths": depths,
                            "finish_reason": output["finish_reason"],
                            "hit_max_tokens": output["finish_reason"] == "length",
                            "runtime_status": "COMPLETE",
                            "scorer_status": "NOT_RUN",
                        }
                        stream.write(json.dumps(record, ensure_ascii=False) + "\n")
                        generated += len(ids)
                batches.append(
                    {
                        "task": task,
                        "start": start,
                        "seconds": result["seconds"],
                        "work": result["work"],
                    }
                )
                print(
                    json.dumps(
                        {
                            "arm": arm["arm_id"],
                            "task": task,
                            "completed": start + len(rows),
                            "tokens": generated,
                        }
                    ),
                    flush=True,
                )
        assert (
            not engine.has_unfinished_requests()
            and engine.cache_manager.num_used_blocks == 0
        )
        assert not engine.model_runner.loopcd_references
        summary = {
            "arm": arm,
            "batches": batches,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "model_load_count": 1,
            "reference_peak_bytes": engine.model_runner.loopcd_stats[
                "reference_peak_bytes"
            ],
            "drained": True,
        }
        write(arm_dir / "summary.json", summary)
        arm_summaries.append(summary)
        engine.close()
        del engine
        gc.collect()
        torch.cuda.empty_cache()
    write(
        args.output / "summary.json",
        {
            "arms": arm_summaries,
            "generated_tokens": generated,
            "gpu_residence_seconds": time.perf_counter() - started,
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("tokenize", "generate"))
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--support", type=Path, required=True)
    parser.add_argument("--data", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "tokenize" and args.data is None:
        parser.error("tokenize requires --data")
    tokenize(args) if args.command == "tokenize" else generate(args)
