"""Independent check of the frozen Re:Loop CP implementation against SciPy."""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

import scipy
from scipy.stats import beta


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location("paired_under_test", args.source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    for n in (1, 2, 16, 128, 164, 436, 437, 504, 505, 1319):
        for comparisons in (1, 2, 4):
            tail = 0.05 / (4 * comparisons)
            for k in sorted({0, 1, n // 2, n - 1, n}):
                for upper in (False, True):
                    expected = (
                        (1.0 if k == n else float(beta.ppf(1 - tail, k + 1, n - k)))
                        if upper
                        else (0.0 if k == 0 else float(beta.ppf(tail, k, n - k + 1)))
                    )
                    actual = module.cp_bound(k, n, tail, upper=upper)
                    rows.append(
                        {
                            "n": n,
                            "k": k,
                            "M": comparisons,
                            "upper": upper,
                            "scipy": expected,
                            "actual": actual,
                            "abs_error": abs(actual - expected),
                        }
                    )
    maximum = max(row["abs_error"] for row in rows)
    result = {
        "status": "PASS" if maximum <= 1e-10 else "FAIL",
        "scipy_version": scipy.__version__,
        "source_sha256": hashlib.sha256(args.source.read_bytes()).hexdigest(),
        "checks": len(rows),
        "max_abs_error": maximum,
        "tolerance": 1e-10,
        "rows": rows,
    }
    args.output.write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )
    print(json.dumps({key: value for key, value in result.items() if key != "rows"}))
    assert result["status"] == "PASS"


if __name__ == "__main__":
    main()
