"""Conservative paired Clopper-Pearson intervals, without optional runtime packages."""

import math


def cp_bound(k: int, n: int, tail: float, *, upper: bool) -> float:
    if not (n > 0 and 0 <= k <= n and 0 < tail < 0.5):
        raise ValueError("invalid binomial counts or tail")
    if upper and k == n:
        return 1.0
    if not upper and k == 0:
        return 0.0
    if upper and k == 0:
        return -math.expm1(math.log(tail) / n)
    count, target = (k, tail) if upper else (k - 1, 1 - tail)
    log_combinations = [
        math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1)
        for i in range(count + 1)
    ]
    low, high = 0.0, 1.0
    for _ in range(64):
        p = (low + high) / 2
        logs = [
            c + i * math.log(p) + (n - i) * math.log1p(-p)
            for i, c in enumerate(log_combinations)
        ]
        peak = max(logs)
        cdf = math.exp(peak) * math.fsum(math.exp(value - peak) for value in logs)
        if cdf > target:
            low = p
        else:
            high = p
    return (low + high) / 2


def paired_ci(wins: int, losses: int, n: int, family_comparisons: int = 1):
    if any(type(value) is not int for value in (wins, losses, n, family_comparisons)):
        raise ValueError("counts and family size must be integers")
    if not (
        n > 0
        and min(wins, losses) >= 0
        and wins + losses <= n
        and family_comparisons >= 1
    ):
        raise ValueError("invalid paired counts")
    tail = 0.05 / (4 * family_comparisons)
    return {
        "n": n,
        "wins": wins,
        "losses": losses,
        "family_comparisons": family_comparisons,
        "difference": (wins - losses) / n,
        "lower": cp_bound(wins, n, tail, upper=False)
        - cp_bound(losses, n, tail, upper=True),
        "upper": cp_bound(wins, n, tail, upper=True)
        - cp_bound(losses, n, tail, upper=False),
    }


def classify(
    lower: float, upper: float, *, complete: bool, scorer_ran: bool, delta: float = 0.01
) -> str:
    if not scorer_ran:
        return "NOT_RUN"
    if not complete:
        return "INCOMPLETE"
    if not (
        math.isfinite(lower) and math.isfinite(upper) and -1 <= lower <= upper <= 1
    ):
        raise ValueError("invalid interval")
    if lower > -delta:
        return "PASS_NI"
    if upper < -delta:
        return "DEGRADED"
    return "UNCERTAIN"
